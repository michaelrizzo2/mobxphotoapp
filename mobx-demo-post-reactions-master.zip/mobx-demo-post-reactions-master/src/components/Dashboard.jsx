import React, { Component } from "react";

export class Dashboard extends Component {
 render() {
   return (
     <div>
       Webpack configuration setup successfully
     </div>
   )
 }
}

export default Dashboard